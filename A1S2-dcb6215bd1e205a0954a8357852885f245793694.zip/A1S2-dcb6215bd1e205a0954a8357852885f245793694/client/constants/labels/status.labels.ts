export const STATUS_LABELS = {
 ACTIVE: 'Aktif',
 INACTIVE: 'Pasif',
 GRADUATED: 'Mezun',
} as const;
