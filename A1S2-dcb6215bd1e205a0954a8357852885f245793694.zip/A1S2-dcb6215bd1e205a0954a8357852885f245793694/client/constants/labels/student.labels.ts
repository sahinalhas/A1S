export const STUDENT_LABELS = {
 FIRST_NAME: 'Ad',
 LAST_NAME: 'Soyad',
 FULL_NAME: 'Ad Soyad',
 CLASS: 'Sınıf',
 GENDER: 'Cinsiyet',
 SCORE: 'Puan',
 RISK: 'Risk',
 PHONE: 'Telefon',
 EMAIL: 'E-posta',
 ADDRESS: 'Adres',
 BIRTH_DATE: 'Doğum Tarihi',
} as const;
