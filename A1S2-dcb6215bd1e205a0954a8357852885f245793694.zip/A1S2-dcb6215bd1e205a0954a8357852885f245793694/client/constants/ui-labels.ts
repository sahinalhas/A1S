export { UI_LABELS } from './labels/index';
export type { UILabel } from './labels/index';