/**
 * Merkezi Tab Yönetim Sistemi
 * Tüm programdaki tab yapılandırmaları burada yönetilir
 */

export * from "./types";
export * from "./settings-tabs";
export * from "./student-profile-tabs";
